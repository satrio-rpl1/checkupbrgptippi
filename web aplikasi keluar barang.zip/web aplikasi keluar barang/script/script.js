
        // Data login yang valid
        const validUsers = [
            { username: 'admin', password: 'admin123', role: 'admin', name: 'Administrator', avatarColor: '#4361ee' },
            { username: 'security', password: 'security123', role: 'security', name: 'Security Officer', avatarColor: '#3a86ff' }
        ];
        
        // Data contoh untuk inventory barang dengan foto
        let inventoryData = [
          
        ];
        
        // Variabel global
        let currentUser = null;
        let nextId = 9;
        let currentExportType = 'inventory';
        let filteredReportData = [];
        let selectedLoginRole = '';
        let currentPhotos = {
            driver: null,
            truck: null,
            item: null
        };
        
        // Format tanggal Indonesia
        function formatDate(date) {
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            return date.toLocaleDateString('id-ID', options);
        }
        
        // Format waktu
        function formatTime(date) {
            return date.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
        }
        
        // Fungsi untuk memilih role di login
        function selectRole(role) {
            selectedLoginRole = role;
            document.getElementById('selectedRole').value = role;
            
            // Update UI role selection
            document.querySelectorAll('.role-option').forEach(option => {
                option.classList.remove('selected');
            });
            document.querySelector(`.role-option[data-role="${role}"]`).classList.add('selected');
            
            // Update login button color based on role
            const loginBtn = document.getElementById('loginBtn');
            if (role === 'admin') {
                loginBtn.style.background = 'linear-gradient(to right, var(--primary), var(--primary-dark))';
            } else if (role === 'security') {
                loginBtn.style.background = 'linear-gradient(to right, var(--security), var(--security-dark))';
            }
        }
        
        // Fungsi untuk menampilkan halaman login
        function showLoginPage() {
            document.getElementById('loginPage').classList.remove('d-none');
            document.getElementById('dashboardPage').classList.add('d-none');
            document.getElementById('username').value = '';
            document.getElementById('password').value = '';
            document.getElementById('selectedRole').value = '';
            document.getElementById('errorMessage').classList.add('d-none');
            
            // Reset role selection
            selectedLoginRole = '';
            document.querySelectorAll('.role-option').forEach(option => {
                option.classList.remove('selected');
            });
            
            // Reset login button
            document.getElementById('loginBtn').style.background = 'linear-gradient(to right, var(--primary), var(--secondary))';
            
            // Reset photos
            currentPhotos = { driver: null, truck: null, item: null };
        }
        
        // Fungsi untuk menampilkan dashboard
        function showDashboardPage(user) {
            document.getElementById('loginPage').classList.add('d-none');
            document.getElementById('dashboardPage').classList.remove('d-none');
            
            currentUser = user;
            
            // Update UI dengan info user
            document.getElementById('currentUser').textContent = user.name;
            document.getElementById('currentRole').textContent = user.role === 'admin' ? 'Administrator' : 'Security Officer';
            
            // Update avatar berdasarkan role
            const userAvatar = document.getElementById('userAvatar');
            userAvatar.textContent = user.name.charAt(0);
            userAvatar.className = `user-avatar ${user.role}`;
            userAvatar.style.background = `linear-gradient(to right, ${user.avatarColor}, ${user.avatarColor}99)`;
            
            // Update dashboard user info
            document.getElementById('dashboardUserName').textContent = user.name;
            document.getElementById('dashboardUserRole').textContent = user.role === 'admin' ? 'Administrator' : 'Security Officer';
            document.getElementById('dashboardUserDesc').textContent = user.role === 'admin' 
                ? 'Anda login dengan akses penuh ke semua fitur sistem.' 
                : 'Anda login sebagai Security Officer dengan kemampuan upload foto saat check in.';
            
            // Update dashboard user avatar
            const dashboardUserAvatar = document.getElementById('dashboardUserAvatar');
            dashboardUserAvatar.textContent = user.name.charAt(0);
            dashboardUserAvatar.className = `user-avatar ${user.role}`;
            dashboardUserAvatar.style.background = `linear-gradient(to right, ${user.avatarColor}, ${user.avatarColor}99)`;
            
            // Update tanggal
            document.getElementById('currentDate').textContent = formatDate(new Date());
            
            // Set default date untuk filter
            const today = new Date().toISOString().split('T')[0];
            const weekAgo = new Date();
            weekAgo.setDate(weekAgo.getDate() - 7);
            document.getElementById('reportDateFrom').value = weekAgo.toISOString().split('T')[0];
            document.getElementById('reportDateTo').value = today;
            
            // Update UI berdasarkan role
            updateUIForRole(user.role);
            
            // Load data awal
            loadDashboardData();
            loadCheckoutTable();
            loadInventoryTable();
            loadRecentActivity();
            
            // Default ke tab dashboard
            switchTab('dashboard');
        }
        
        // Update UI berdasarkan role pengguna
        function updateUIForRole(role) {
            const inventoryTabNav = document.getElementById('inventoryTabNav');
            const reportTabNav = document.getElementById('reportTabNav');
            const dashboardExportBtn = document.getElementById('dashboardExportBtn');
            const inventoryExportBtn = document.getElementById('inventoryExportBtn');
            const exportExcelBtn = document.getElementById('exportExcelBtn');
            const exportCSVBtn = document.getElementById('exportCSVBtn');
            const securityBadge = document.getElementById('securityBadge');
            const securityViewInfo = document.getElementById('securityViewInfo');
            const photoUploadSection = document.getElementById('photoUploadSection');
            const photoViewSection = document.getElementById('photoViewSection');
            
            if (role === 'security') {
                // Security tidak bisa akses inventory dan report
                inventoryTabNav.classList.add('d-none');
                reportTabNav.classList.add('d-none');
                
                // Security tidak bisa export data
                dashboardExportBtn.classList.add('d-none');
                inventoryExportBtn.classList.add('d-none');
                exportExcelBtn.classList.add('d-none');
                exportCSVBtn.classList.add('d-none');
                
                // Tampilkan badge security
                securityBadge.classList.remove('d-none');
                
                // Tampilkan info security view
                securityViewInfo.classList.remove('d-none');
                
                // Tampilkan photo upload section untuk security
                photoUploadSection.classList.remove('d-none');
                photoViewSection.classList.add('d-none');
                
                // Update photo upload section untuk security
                photoUploadSection.classList.add('security');
                
                // Update card headers untuk security
                document.querySelectorAll('.card-header').forEach(header => {
                    header.classList.remove('admin');
                    header.classList.add('security');
                });
                
                // Update table headers untuk security
                document.querySelectorAll('.data-table').forEach(table => {
                    table.classList.remove('admin');
                    table.classList.add('security');
                });
                
                // Update summary cards untuk security
                document.querySelectorAll('.summary-card').forEach(card => {
                    card.classList.add('security');
                });
                
                // Update dashboard subtitle
                document.getElementById('dashboardSubtitle').textContent = 'Melakukan check in dan check out barang dengan bukti foto';
                
            } else {
                // Admin bisa akses semua
                inventoryTabNav.classList.remove('d-none');
                reportTabNav.classList.remove('d-none');
                
                // Admin bisa export data
                dashboardExportBtn.classList.remove('d-none');
                inventoryExportBtn.classList.remove('d-none');
                exportExcelBtn.classList.remove('d-none');
                exportCSVBtn.classList.remove('d-none');
                
                // Sembunyikan badge security
                securityBadge.classList.add('d-none');
                
                // Sembunyikan info security view
                securityViewInfo.classList.add('d-none');
                
                // Sembunyikan photo upload, tampilkan photo view untuk admin
                photoUploadSection.classList.add('d-none');
                photoViewSection.classList.remove('d-none');
                
                // Update card headers untuk admin
                document.querySelectorAll('.card-header').forEach(header => {
                    header.classList.remove('security');
                    header.classList.add('admin');
                });
                
                // Update table headers untuk admin
                document.querySelectorAll('.data-table').forEach(table => {
                    table.classList.remove('security');
                    table.classList.add('admin');
                });
                
                // Update summary cards untuk admin
                document.querySelectorAll('.summary-card').forEach(card => {
                    card.classList.remove('security');
                });
                
                // Update dashboard subtitle
                document.getElementById('dashboardSubtitle').textContent = 'Monitor dan keluar masuk barang dengan aman dan teratur';
            }
        }
        
        // Fungsi untuk login
        function login() {
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const role = document.getElementById('selectedRole').value;
            
            // Validasi input
            if (!username || !password || !role) {
                document.getElementById('errorMessage').textContent = 'Harap pilih peran dan isi username/password!';
                document.getElementById('errorMessage').classList.remove('d-none');
                return;
            }
            
            // Cek kredensial
            const user = validUsers.find(u => 
                u.username === username && 
                u.password === password && 
                u.role === role
            );
            
            if (user) {
                showDashboardPage(user);
            } else {
                document.getElementById('errorMessage').textContent = 'Username, password atau peran salah!';
                document.getElementById('errorMessage').classList.remove('d-none');
            }
        }
        
        // Fungsi untuk logout
        function logout() {
            showLoginPage();
        }
        
        // Fungsi untuk beralih tab
        function switchTab(tabName) {
            // Sembunyikan semua tab
            document.querySelectorAll('.content-card').forEach(tab => {
                tab.classList.add('d-none');
            });
            
            // Tampilkan tab yang dipilih
            document.getElementById(tabName + 'Tab').classList.remove('d-none');
            
            // Update menu aktif
            document.querySelectorAll('.menu-item').forEach(item => {
                item.classList.remove('active');
                if (item.getAttribute('data-tab') === tabName) {
                    item.classList.add('active');
                    
                    // Update active border color berdasarkan role
                    if (currentUser.role === 'admin') {
                        item.classList.add('admin');
                        item.classList.remove('security');
                    } else {
                        item.classList.add('security');
                        item.classList.remove('admin');
                    }
                }
            });
            
            // Update judul dashboard
            const titles = {
                'dashboard': 'Dashboard Pengamanan Aset',
                'checkin': 'Check In Barang Baru',
                'checkout': 'Check Out Barang',
                'inventory': 'Inventory Barang',
                'report': 'Laporan & Statistik'
            };
            
            document.getElementById('dashboardTitle').textContent = titles[tabName] || 'Dashboard';
            
            // Reset photo previews jika beralih ke checkin tab
            if (tabName === 'checkin') {
                resetPhotoPreviews();
            }
            
            // Jika tab report, generate report (hanya untuk admin)
            if (tabName === 'report' && currentUser.role === 'admin') {
                generateReport();
            }
            
            // Jika tab inventory/report dan user adalah security, redirect ke dashboard
            if ((tabName === 'inventory' || tabName === 'report') && currentUser.role === 'security') {
                switchTab('dashboard');
                showNotification('Akses ditolak! Hanya Administrator yang dapat mengakses fitur ini.', 'danger');
            }
        }
        
        // Fungsi untuk trigger photo upload
        function triggerPhotoUpload(type) {
            if (currentUser.role !== 'security') {
                showNotification('Hanya Security Officer yang dapat mengupload foto!', 'danger');
                return;
            }
            
            document.getElementById(`${type}Photo`).click();
        }
        
        // Fungsi untuk preview photo
        function previewPhoto(event, type) {
            const file = event.target.files[0];
            if (!file) return;
            
            // Validasi ukuran file (max 5MB)
            if (file.size > 5 * 1024 * 1024) {
                showNotification('Ukuran file terlalu besar! Maksimal 5MB.', 'danger');
                return;
            }
            
            // Validasi tipe file
            if (!file.type.match('image.*')) {
                showNotification('File harus berupa gambar!', 'danger');
                return;
            }
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const preview = document.getElementById(`${type}PhotoPreview`);
                const container = document.getElementById(`${type}PhotoContainer`);
                const removeBtn = container.querySelector('.remove-photo');
                
                // Simpan photo data
                currentPhotos[type] = e.target.result;
                
                // Tampilkan preview
                preview.src = e.target.result;
                preview.classList.add('active');
                
                // Tampilkan remove button
                removeBtn.classList.add('active');
                
                // Sembunyikan placeholder
                container.querySelector('i').style.display = 'none';
                container.querySelector('p').style.display = 'none';
                container.querySelector('small').style.display = 'none';
                
                showNotification(`Foto ${type === 'driver' ? 'supir' : type === 'truck' ? 'truck' : 'barang'} berhasil diupload!`, 'success');
            };
            reader.readAsDataURL(file);
        }
        
        // Fungsi untuk remove photo
        function removePhoto(type) {
            currentPhotos[type] = null;
            
            const preview = document.getElementById(`${type}PhotoPreview`);
            const container = document.getElementById(`${type}PhotoContainer`);
            const removeBtn = container.querySelector('.remove-photo');
            const fileInput = document.getElementById(`${type}Photo`);
            
            // Reset preview
            preview.src = '';
            preview.classList.remove('active');
            
            // Sembunyikan remove button
            removeBtn.classList.remove('active');
            
            // Tampilkan placeholder
            container.querySelector('i').style.display = 'block';
            container.querySelector('p').style.display = 'block';
            container.querySelector('small').style.display = 'block';
            
            // Reset file input
            fileInput.value = '';
            
            showNotification(`Foto ${type === 'driver' ? 'supir' : type === 'truck' ? 'truck' : 'barang'} dihapus!`, 'warning');
        }
        
        // Fungsi untuk reset photo previews
        function resetPhotoPreviews() {
            currentPhotos = { driver: null, truck: null, item: null };
            
            // Reset semua preview
            ['driver', 'truck', 'item'].forEach(type => {
                const preview = document.getElementById(`${type}PhotoPreview`);
                const container = document.getElementById(`${type}PhotoContainer`);
                const removeBtn = container.querySelector('.remove-photo');
                const fileInput = document.getElementById(`${type}Photo`);
                
                // Reset preview
                preview.src = '';
                preview.classList.remove('active');
                
                // Sembunyikan remove button
                removeBtn.classList.remove('active');
                
                // Tampilkan placeholder
                container.querySelector('i').style.display = 'block';
                container.querySelector('p').style.display = 'block';
                container.querySelector('small').style.display = 'block';
                
                // Reset file input
                fileInput.value = '';
            });
        }
        
        // Fungsi untuk menambahkan data check in
        function addCheckinData() {
            const departemen = document.getElementById('departemen').value;
            const supir = document.getElementById('supir').value;
            const truck = document.getElementById('truck').value;
            const nopol = document.getElementById('nopol').value;
            const barang = document.getElementById('barang').value;
            const quantity = document.getElementById('quantity').value;
            const ptAsal = document.getElementById('ptAsal').value;
            const ptTujuan = document.getElementById('ptTujuan').value;
            const keterangan = document.getElementById('keterangan').value;
            
            // Validasi input
            if (!departemen || !supir || !truck || !nopol || !barang || !ptAsal || !ptTujuan) {
                showNotification('Harap isi semua field yang wajib!', 'danger');
                return;
            }
            
            // Tambah data baru ke inventory
            const now = new Date();
            const newItem = {
                id: nextId++,
                departemen: departemen,
                supir: supir,
                truck: truck,
                barang: barang,
                quantity: quantity,
                nopol: nopol,
                ptAsal: ptAsal,
                ptTujuan: ptTujuan,
                keterangan: keterangan,
                status: 'checkin',
                checkinTime: `${now.toISOString().split('T')[0]} ${formatTime(now)}`,
                checkoutTime: null,
                checkedBy: currentUser.name,
                photos: currentUser.role === 'security' ? {...currentPhotos} : { driver: null, truck: null, item: null }
            };
            
            inventoryData.unshift(newItem); // Tambah di awal array
            
            // Reset form dan photo previews
            resetCheckinForm();
            resetPhotoPreviews();
            
            // Tampilkan notifikasi
            showNotification('Data check in berhasil disimpan!' + (currentUser.role === 'security' && hasPhotos() ? ' dengan foto.' : ''), 'success');
            
            // Update semua data
            loadDashboardData();
            loadCheckoutTable();
            loadInventoryTable();
            loadRecentActivity();
            
            // Beralih ke tab dashboard
            switchTab('dashboard');
        }
        
        // Fungsi untuk cek apakah ada foto yang diupload
        function hasPhotos() {
            return currentPhotos.driver || currentPhotos.truck || currentPhotos.item;
        }
        
        // Fungsi untuk check out barang
        function checkoutItem(id) {
            const itemIndex = inventoryData.findIndex(item => item.id === id);
            
            if (itemIndex !== -1) {
                const now = new Date();
                inventoryData[itemIndex].status = 'checkout';
                inventoryData[itemIndex].checkoutTime = `${now.toISOString().split('T')[0]} ${formatTime(now)}`;
                inventoryData[itemIndex].checkedBy = currentUser.name;
                
                // Update semua data
                loadDashboardData();
                loadCheckoutTable();
                loadInventoryTable();
                loadRecentActivity();
                
                showNotification('Barang berhasil di check out!', 'success');
            }
        }
        
        // Fungsi untuk melihat detail item
        function viewItemDetail(id) {
            const item = inventoryData.find(item => item.id === id);
            
            if (item) {
                const modalContent = document.getElementById('itemDetailContent');
                
                // Buat gallery foto jika ada
                let photoGalleryHTML = '';
                if (item.photos && (item.photos.driver || item.photos.truck || item.photos.item)) {
                    photoGalleryHTML = `
                        <div class="mt-3">
                            <h4>Foto Pemeriksaan</h4>
                            <div class="photo-gallery">
                                ${item.photos.driver ? `
                                <div class="photo-item" onclick="viewPhoto('${item.photos.driver}', 'Foto Supir: ${item.supir}')">
                                    <img src="${item.photos.driver}" alt="Foto Supir">
                                    <div class="photo-item-caption">Foto Supir</div>
                                </div>
                                ` : ''}
                                ${item.photos.truck ? `
                                <div class="photo-item" onclick="viewPhoto('${item.photos.truck}', 'Foto Truck: ${item.truck}')">
                                    <img src="${item.photos.truck}" alt="Foto Truck">
                                    <div class="photo-item-caption">Foto Truck</div>
                                </div>
                                ` : ''}
                                ${item.photos.item ? `
                                <div class="photo-item" onclick="viewPhoto('${item.photos.item}', 'Foto Barang: ${item.barang}')">
                                    <img src="${item.photos.item}" alt="Foto Barang">
                                    <div class="photo-item-caption">Foto Barang</div>
                                </div>
                                ` : ''}
                            </div>
                            ${!item.photos.driver && !item.photos.truck && !item.photos.item ? '<p class="text-muted">Tidak ada foto yang diupload untuk barang ini.</p>' : ''}
                        </div>
                    `;
                }
                
                modalContent.innerHTML = `
                    <div class="form-row">
                        <div class="form-group w-100">
                            <label>Departemen</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.departemen}</div>
                        </div>
                        
                        <div class="form-group w-100">
                            <label>Supir</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.supir}</div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group w-100">
                            <label>Truck</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.truck}</div>
                        </div>
                        
                        <div class="form-group w-100">
                            <label>No Polisi</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.nopol}</div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group w-100">
                            <label>Barang</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.barang} (${item.quantity})</div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group w-100">
                            <label>PT Asal</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.ptAsal}</div>
                        </div>
                        
                        <div class="form-group w-100">
                            <label>PT Tujuan</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.ptTujuan}</div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group w-100">
                            <label>Status</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">
                                <span class="badge ${item.status === 'checkin' ? 'badge-success' : 'badge-warning'}">
                                    ${item.status === 'checkin' ? 'CHECK IN' : 'CHECK OUT'}
                                </span>
                            </div>
                        </div>
                        
                        <div class="form-group w-100">
                            <label>Diperiksa Oleh</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.checkedBy}</div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group w-100">
                            <label>Waktu Check In</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.checkinTime}</div>
                        </div>
                        
                        <div class="form-group w-100">
                            <label>Waktu Check Out</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.checkoutTime || 'Belum check out'}</div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group w-100">
                            <label>Keterangan</label>
                            <div class="p-3" style="background-color: #f8f9ff; border-radius: 8px;">${item.keterangan || '-'}</div>
                        </div>
                    </div>
                    
                    ${photoGalleryHTML}
                `;
                
                // Tampilkan modal
                document.getElementById('itemDetailModal').style.display = 'flex';
            }
        }
        
        // Fungsi untuk view photo di modal besar
        function viewPhoto(photoSrc, caption) {
            document.getElementById('modalPhoto').src = photoSrc;
            document.getElementById('modalPhotoCaption').textContent = caption;
            document.getElementById('photoModal').style.display = 'flex';
        }
        
        // Fungsi untuk memuat data dashboard
        function loadDashboardData() {
            const checkinCount = inventoryData.filter(item => item.status === 'checkin').length;
            const checkoutCount = inventoryData.filter(item => item.status === 'checkout').length;
            const totalCount = inventoryData.length;
            const pendingCount = checkinCount; // Barang yang masih check in dianggap pending
            
            document.getElementById('statCheckin').textContent = checkinCount;
            document.getElementById('statCheckout').textContent = checkoutCount;
            document.getElementById('statTotal').textContent = totalCount;
            document.getElementById('statPending').textContent = pendingCount;
        }
        
        // Fungsi untuk memuat tabel checkout
        function loadCheckoutTable() {
            const tableBody = document.getElementById('checkoutTableBody');
            tableBody.innerHTML = '';
            
            // Hanya tampilkan barang dengan status checkin
            const checkinItems = inventoryData.filter(item => item.status === 'checkin');
            
            checkinItems.forEach((item, index) => {
                const row = document.createElement('tr');
                
                // Cek apakah ada foto
                const hasPhotos = item.photos && (item.photos.driver || item.photos.truck || item.photos.item);
                const photoButton = hasPhotos ? 
                    `<button class="action-btn ${currentUser.role === 'admin' ? 'btn-primary' : 'btn-security'}" onclick="showPhotoGallery(${item.id})">
                        <i class="fas fa-images"></i> Lihat Foto
                    </button>` : 
                    `<span class="text-muted">Tidak ada foto</span>`;
                
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${item.departemen}</td>
                    <td>${item.supir}</td>
                    <td>${item.barang}</td>
                    <td>${item.ptAsal} → ${item.ptTujuan}</td>
                    <td>${item.checkinTime}</td>
                    <td><span class="badge badge-success">CHECK IN</span></td>
                    <td>${photoButton}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="action-btn ${currentUser.role === 'admin' ? 'btn-success' : 'security'}" onclick="checkoutItem(${item.id})">
                                <i class="fas fa-sign-out-alt"></i> Check Out
                            </button>
                            <button class="action-btn ${currentUser.role === 'admin' ? 'btn-primary' : 'btn-security'}" onclick="viewItemDetail(${item.id})">
                                <i class="fas fa-eye"></i> Detail
                            </button>
                        </div>
                    </td>
                `;
                
                tableBody.appendChild(row);
            });
        }
        
        // Fungsi untuk memuat tabel inventory
        function loadInventoryTable() {
            const tableBody = document.getElementById('inventoryTableBody');
            tableBody.innerHTML = '';
            
            inventoryData.forEach((item, index) => {
                const row = document.createElement('tr');
                
                // Cek apakah ada foto
                const hasPhotos = item.photos && (item.photos.driver || item.photos.truck || item.photos.item);
                const photoButton = hasPhotos ? 
                    `<button class="action-btn ${currentUser.role === 'admin' ? 'btn-primary' : 'btn-security'}" onclick="showPhotoGallery(${item.id})">
                        <i class="fas fa-images"></i> Lihat
                    </button>` : 
                    `<span class="text-muted">-</span>`;
                
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${item.departemen}</td>
                    <td>${item.supir}</td>
                    <td>${item.truck}</td>
                    <td>${item.barang}<br><small class="text-muted">${item.quantity}</small></td>
                    <td>${item.nopol}</td>
                    <td>${item.ptAsal} → ${item.ptTujuan}</td>
                    <td><span class="badge ${item.status === 'checkin' ? 'badge-success' : 'badge-warning'}">${item.status === 'checkin' ? 'CHECK IN' : 'CHECK OUT'}</span></td>
                    <td>${item.checkinTime}</td>
                    <td>${item.checkoutTime || '-'}</td>
                    <td><span class="${item.checkedBy === 'Security Officer' ? 'badge-security' : 'badge-info'}">${item.checkedBy}</span></td>
                    <td>${photoButton}</td>
                    <td>
                        <div class="action-buttons">
                            <button class="action-btn ${currentUser.role === 'admin' ? 'btn-primary' : 'btn-security'}" onclick="viewItemDetail(${item.id})">
                                <i class="fas fa-eye"></i>
                            </button>
                            ${item.status === 'checkin' && currentUser.role === 'admin' ? `
                            <button class="action-btn btn-success" onclick="checkoutItem(${item.id})">
                                <i class="fas fa-sign-out-alt"></i>
                            </button>
                            ` : ''}
                        </div>
                    </td>
                `;
                
                tableBody.appendChild(row);
            });
        }
        
        // Fungsi untuk memuat aktivitas terbaru
        function loadRecentActivity() {
            const tableBody = document.getElementById('recentActivityTable');
            tableBody.innerHTML = '';
            
            // Ambil 5 aktivitas terbaru
            const recentItems = [...inventoryData]
                .sort((a, b) => new Date(b.checkinTime) - new Date(a.checkinTime))
                .slice(0, 5);
            
            recentItems.forEach(item => {
                // Cek apakah ada foto
                const hasPhotos = item.photos && (item.photos.driver || item.photos.truck || item.photos.item);
                const photoButton = hasPhotos ? 
                    `<button class="action-btn btn-primary" onclick="showPhotoGallery(${item.id})" style="padding: 4px 8px; font-size: 12px;">
                        <i class="fas fa-camera"></i> Foto
                    </button>` : 
                    `<span class="text-muted">-</span>`;
                
                const row = document.createElement('tr');
                
                row.innerHTML = `
                    <td>${item.checkinTime.split(' ')[1]}</td>
                    <td>${item.departemen}</td>
                    <td>${item.barang}</td>
                    <td><span class="badge ${item.status === 'checkin' ? 'badge-success' : 'badge-warning'}">${item.status === 'checkin' ? 'CHECK IN' : 'CHECK OUT'}</span></td>
                    <td><span class="${item.checkedBy === 'Security Officer' ? 'badge-security' : 'badge-info'}">${item.checkedBy}</span></td>
                    <td>${photoButton}</td>
                `;
                
                tableBody.appendChild(row);
            });
        }
        
        // Fungsi untuk menampilkan gallery foto
        function showPhotoGallery(itemId) {
            const item = inventoryData.find(item => item.id === itemId);
            
            if (!item) return;
            
            const modalContent = document.getElementById('photoGalleryContent');
            
            if (!item.photos || (!item.photos.driver && !item.photos.truck && !item.photos.item)) {
                modalContent.innerHTML = `
                    <div class="text-center p-5">
                        <i class="fas fa-images" style="font-size: 48px; color: var(--gray-light); margin-bottom: 15px;"></i>
                        <p class="text-muted">Tidak ada foto yang diupload untuk barang ini.</p>
                    </div>
                `;
            } else {
                modalContent.innerHTML = `
                    <h4 class="mb-3">Foto Pemeriksaan Barang</h4>
                    <p class="text-muted mb-4">Barang: ${item.barang} | Supir: ${item.supir} | Diperiksa oleh: ${item.checkedBy}</p>
                    
                    <div class="photo-gallery">
                        ${item.photos.driver ? `
                        <div class="photo-item" onclick="viewPhoto('${item.photos.driver}', 'Foto Supir: ${item.supir}')">
                            <img src="${item.photos.driver}" alt="Foto Supir">
                            <div class="photo-item-caption">Foto Supir</div>
                        </div>
                        ` : ''}
                        ${item.photos.truck ? `
                        <div class="photo-item" onclick="viewPhoto('${item.photos.truck}', 'Foto Truck: ${item.truck}')">
                            <img src="${item.photos.truck}" alt="Foto Truck">
                            <div class="photo-item-caption">Foto Truck</div>
                        </div>
                        ` : ''}
                        ${item.photos.item ? `
                        <div class="photo-item" onclick="viewPhoto('${item.photos.item}', 'Foto Barang: ${item.barang}')">
                            <img src="${item.photos.item}" alt="Foto Barang">
                            <div class="photo-item-caption">Foto Barang</div>
                        </div>
                        ` : ''}
                    </div>
                    
                    <div class="mt-4">
                        <p class="text-muted"><small><i class="fas fa-info-circle"></i> Klik pada foto untuk melihat dalam ukuran penuh</small></p>
                    </div>
                `;
            }
            
            document.getElementById('photoGalleryModal').style.display = 'flex';
        }
        
        // Fungsi untuk reset form check in
        function resetCheckinForm() {
            document.getElementById('departemen').value = '';
            document.getElementById('supir').value = '';
            document.getElementById('truck').value = '';
            document.getElementById('nopol').value = '';
            document.getElementById('barang').value = '';
            document.getElementById('quantity').value = '';
            document.getElementById('ptAsal').value = '';
            document.getElementById('ptTujuan').value = '';
            document.getElementById('keterangan').value = '';
        }
        
        // Fungsi untuk generate report
        function generateReport() {
            // Ambil nilai filter
            const statusFilter = document.getElementById('reportStatus').value;
            const deptFilter = document.getElementById('reportDepartment').value;
            const dateFrom = document.getElementById('reportDateFrom').value;
            const dateTo = document.getElementById('reportDateTo').value;
            
            // Filter data berdasarkan kriteria
            filteredReportData = [...inventoryData];
            
            // Filter berdasarkan status
            if (statusFilter !== 'all') {
                filteredReportData = filteredReportData.filter(item => item.status === statusFilter);
            }
            
            // Filter berdasarkan departemen
            if (deptFilter !== 'all') {
                filteredReportData = filteredReportData.filter(item => item.departemen === deptFilter);
            }
            
            // Filter berdasarkan tanggal
            if (dateFrom) {
                filteredReportData = filteredReportData.filter(item => {
                    const itemDate = item.checkinTime.split(' ')[0];
                    return itemDate >= dateFrom;
                });
            }
            
            if (dateTo) {
                filteredReportData = filteredReportData.filter(item => {
                    const itemDate = item.checkinTime.split(' ')[0];
                    return itemDate <= dateTo;
                });
            }
            
            // Update statistik laporan
            const totalCheckin = filteredReportData.filter(item => item.status === 'checkin').length;
            const totalCheckout = filteredReportData.filter(item => item.status === 'checkout').length;
            const totalPending = totalCheckin;
            
            // Hitung rata-rata waktu check in ke check out
            const checkoutItems = filteredReportData.filter(item => item.status === 'checkout' && item.checkoutTime);
            let totalHours = 0;
            
            checkoutItems.forEach(item => {
                const checkinDate = new Date(item.checkinTime);
                const checkoutDate = new Date(item.checkoutTime);
                const diffHours = (checkoutDate - checkinDate) / (1000 * 60 * 60);
                totalHours += diffHours;
            });
            
            const avgTime = checkoutItems.length > 0 ? (totalHours / checkoutItems.length).toFixed(1) : 0;
            
            // Update UI statistik
            document.getElementById('reportTotalCheckin').textContent = totalCheckin;
            document.getElementById('reportTotalCheckout').textContent = totalCheckout;
            document.getElementById('reportTotalPending').textContent = totalPending;
            document.getElementById('reportAvgTime').textContent = avgTime;
            
            // Update tabel laporan
            const tableBody = document.getElementById('reportTableBody');
            tableBody.innerHTML = '';
            
            filteredReportData.forEach((item, index) => {
                // Cek apakah ada foto
                const hasPhotos = item.photos && (item.photos.driver || item.photos.truck || item.photos.item);
                const photoButton = hasPhotos ? 
                    `<button class="action-btn btn-primary" onclick="showPhotoGallery(${item.id})" style="padding: 4px 8px; font-size: 12px;">
                        <i class="fas fa-images"></i> Lihat
                    </button>` : 
                    `<span class="text-muted">-</span>`;
                
                const row = document.createElement('tr');
                
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${item.checkinTime.split(' ')[0]}</td>
                    <td>${item.departemen}</td>
                    <td>${item.supir}</td>
                    <td>${item.barang} (${item.quantity})</td>
                    <td>${item.ptAsal} → ${item.ptTujuan}</td>
                    <td>${item.truck}</td>
                    <td><span class="badge ${item.status === 'checkin' ? 'badge-success' : 'badge-warning'}">${item.status === 'checkin' ? 'CHECK IN' : 'CHECK OUT'}</span></td>
                    <td>${item.checkinTime}</td>
                    <td>${item.checkoutTime || '-'}</td>
                    <td><span class="${item.checkedBy === 'Security Officer' ? 'badge-security' : 'badge-info'}">${item.checkedBy}</span></td>
                    <td>${photoButton}</td>
                `;
                
                tableBody.appendChild(row);
            });
            
            // Generate charts
            generateCharts(filteredReportData);
            
            showNotification('Laporan berhasil digenerate!', 'success');
        }
        
        // Fungsi untuk generate charts
        function generateCharts(data) {
            // Chart 1: Distribusi Status Barang
            const statusChart = document.getElementById('statusChart');
            statusChart.innerHTML = '';
            
            // Hitung data status
            const checkinCount = data.filter(item => item.status === 'checkin').length;
            const checkoutCount = data.filter(item => item.status === 'checkout').length;
            const totalCount = data.length;
            
            // Hitung persentase
            const checkinPercent = totalCount > 0 ? (checkinCount / totalCount * 100).toFixed(0) : 0;
            const checkoutPercent = totalCount > 0 ? (checkoutCount / totalCount * 100).toFixed(0) : 0;
            
            // Buat bar untuk check in
            const checkinBar = document.createElement('div');
            checkinBar.className = 'bar-container';
            const checkinBarHeight = totalCount > 0 ? (checkinCount / totalCount * 180) : 0;
            checkinBar.innerHTML = `
                <div class="bar" style="height: ${checkinBarHeight}px; background-color: #06d6a0;" title="Check In: ${checkinCount} item (${checkinPercent}%)"></div>
                <div class="bar-label">Check In<br>${checkinCount}</div>
            `;
            statusChart.appendChild(checkinBar);
            
            // Buat bar untuk check out
            const checkoutBar = document.createElement('div');
            checkoutBar.className = 'bar-container';
            const checkoutBarHeight = totalCount > 0 ? (checkoutCount / totalCount * 180) : 0;
            checkoutBar.innerHTML = `
                <div class="bar" style="height: ${checkoutBarHeight}px; background-color: #ffd166;" title="Check Out: ${checkoutCount} item (${checkoutPercent}%)"></div>
                <div class="bar-label">Check Out<br>${checkoutCount}</div>
            `;
            statusChart.appendChild(checkoutBar);
            
            // Chart 2: Aktivitas per Departemen
            const deptChart = document.getElementById('departmentChart');
            deptChart.innerHTML = '';
            
            // Hitung data per departemen
            const departments = {};
            data.forEach(item => {
                if (!departments[item.departemen]) {
                    departments[item.departemen] = 0;
                }
                departments[item.departemen]++;
            });
            
            // Warna untuk setiap departemen
            const deptColors = {
                'Logistik': '#4361ee',
                'Gudang': '#7209b7',
                'Produksi': '#ef476f'
            };
            
            // Buat bar untuk setiap departemen
            for (const [deptName, deptCount] of Object.entries(departments)) {
                const deptBar = document.createElement('div');
                deptBar.className = 'bar-container';
                const deptBarHeight = totalCount > 0 ? (deptCount / totalCount * 180) : 0;
                const deptPercent = totalCount > 0 ? (deptCount / totalCount * 100).toFixed(0) : 0;
                
                deptBar.innerHTML = `
                    <div class="bar" style="height: ${deptBarHeight}px; background-color: ${deptColors[deptName] || '#6c757d'};" title="${deptName}: ${deptCount} item (${deptPercent}%)"></div>
                    <div class="bar-label">${deptName}<br>${deptCount}</div>
                `;
                deptChart.appendChild(deptBar);
            }
        }
        
        // Fungsi untuk menampilkan modal export
        function showExportModal(type) {
            if (currentUser.role !== 'admin') {
                showNotification('Hanya Administrator yang dapat mengexport data!', 'danger');
                return;
            }
            
            currentExportType = type;
            document.getElementById('exportModal').style.display = 'flex';
        }
        
        // Fungsi untuk export ke Excel
        function exportToExcel(type) {
            if (currentUser.role !== 'admin') {
                showNotification('Hanya Administrator yang dapat mengexport data!', 'danger');
                return;
            }
            
            let dataToExport = [];
            let filename = '';
            
            // Tentukan data yang akan diexport berdasarkan tipe
            if (type === 'report') {
                dataToExport = filteredReportData.length > 0 ? filteredReportData : inventoryData;
                filename = `Laporan_Pemeriksaan_Barang_${new Date().toISOString().split('T')[0]}.xlsx`;
            } else if (type === 'inventory') {
                dataToExport = inventoryData;
                filename = `Inventory_Barang_${new Date().toISOString().split('T')[0]}.xlsx`;
            } else if (type === 'dashboard') {
                // Export aktivitas terbaru dari dashboard
                dataToExport = [...inventoryData]
                    .sort((a, b) => new Date(b.checkinTime) - new Date(a.checkinTime))
                    .slice(0, 10);
                filename = `Aktivitas_Terbaru_${new Date().toISOString().split('T')[0]}.xlsx`;
            }
            
            if (dataToExport.length === 0) {
                showNotification('Tidak ada data untuk diexport!', 'warning');
                return;
            }
            
            // Siapkan data untuk Excel
            const excelData = dataToExport.map(item => ({
                'No': dataToExport.indexOf(item) + 1,
                'Departemen': item.departemen,
                'Nama Supir': item.supir,
                'Jenis Truck': item.truck,
                'Barang': item.barang,
                'Kuantitas': item.quantity,
                'No. Polisi': item.nopol,
                'PT Asal': item.ptAsal,
                'PT Tujuan': item.ptTujuan,
                'Status': item.status === 'checkin' ? 'CHECK IN' : 'CHECK OUT',
                'Waktu Check In': item.checkinTime,
                'Waktu Check Out': item.checkoutTime || '-',
                'Diperiksa Oleh': item.checkedBy,
                'Ada Foto': (item.photos && (item.photos.driver || item.photos.truck || item.photos.item)) ? 'Ya' : 'Tidak',
                'Keterangan': item.keterangan || '-'
            }));
            
            // Buat worksheet
            const ws = XLSX.utils.json_to_sheet(excelData);
            
            // Buat workbook
            const wb = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(wb, ws, "Data Barang");
            
            // Tambah sheet untuk statistik
            const statsData = [
                { 'Statistik': 'Total Data', 'Nilai': dataToExport.length },
                { 'Statistik': 'Check In', 'Nilai': dataToExport.filter(item => item.status === 'checkin').length },
                { 'Statistik': 'Check Out', 'Nilai': dataToExport.filter(item => item.status === 'checkout').length },
                { 'Statistik': 'Data dengan Foto', 'Nilai': dataToExport.filter(item => item.photos && (item.photos.driver || item.photos.truck || item.photos.item)).length },
                { 'Statistik': 'Tanggal Export', 'Nilai': new Date().toLocaleDateString('id-ID') },
                { 'Statistik': 'Diexport Oleh', 'Nilai': currentUser.name }
            ];
            
            const ws2 = XLSX.utils.json_to_sheet(statsData);
            XLSX.utils.book_append_sheet(wb, ws2, "Statistik");
            
            // Export ke file
            XLSX.writeFile(wb, filename);
            
            showNotification(`Data berhasil diexport ke Excel (${filename})`, 'success');
            document.getElementById('exportModal').style.display = 'none';
        }
        
        // Fungsi untuk export ke CSV
        function exportToCSV(type) {
            if (currentUser.role !== 'admin') {
                showNotification('Hanya Administrator yang dapat mengexport data!', 'danger');
                return;
            }
            
            let dataToExport = [];
            let filename = '';
            
            // Tentukan data yang akan diexport berdasarkan tipe
            if (type === 'report') {
                dataToExport = filteredReportData.length > 0 ? filteredReportData : inventoryData;
                filename = `Laporan_Pemeriksaan_Barang_${new Date().toISOString().split('T')[0]}.csv`;
            } else if (type === 'inventory') {
                dataToExport = inventoryData;
                filename = `Inventory_Barang_${new Date().toISOString().split('T')[0]}.csv`;
            } else if (type === 'dashboard') {
                // Export aktivitas terbaru dari dashboard
                dataToExport = [...inventoryData]
                    .sort((a, b) => new Date(b.checkinTime) - new Date(a.checkinTime))
                    .slice(0, 10);
                filename = `Aktivitas_Terbaru_${new Date().toISOString().split('T')[0]}.csv`;
            }
            
            if (dataToExport.length === 0) {
                showNotification('Tidak ada data untuk diexport!', 'warning');
                return;
            }
            
            // Header CSV
            const headers = ['No', 'Departemen', 'Nama Supir', 'Jenis Truck', 'Barang', 'Kuantitas', 'No. Polisi', 'PT Asal', 'PT Tujuan', 'Status', 'Waktu Check In', 'Waktu Check Out', 'Diperiksa Oleh', 'Ada Foto', 'Keterangan'];
            
            // Data CSV
            const csvData = dataToExport.map((item, index) => [
                index + 1,
                item.departemen,
                item.supir,
                item.truck,
                item.barang,
                item.quantity,
                item.nopol,
                item.ptAsal,
                item.ptTujuan,
                item.status === 'checkin' ? 'CHECK IN' : 'CHECK OUT',
                item.checkinTime,
                item.checkoutTime || '-',
                item.checkedBy,
                (item.photos && (item.photos.driver || item.photos.truck || item.photos.item)) ? 'Ya' : 'Tidak',
                item.keterangan || '-'
            ]);
            
            // Gabungkan header dan data
            const csvContent = [
                headers.join(','),
                ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
            ].join('\n');
            
            // Buat blob dan download
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement("a");
            const url = URL.createObjectURL(blob);
            
            link.setAttribute("href", url);
            link.setAttribute("download", filename);
            link.style.visibility = 'hidden';
            
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            showNotification(`Data berhasil diexport ke CSV (${filename})`, 'success');
            document.getElementById('exportModal').style.display = 'none';
        }
        
        // Fungsi untuk export ke PDF (simulasi)
        function exportToPDF() {
            if (currentUser.role !== 'admin') {
                showNotification('Hanya Administrator yang dapat mengexport data!', 'danger');
                return;
            }
            
            showNotification('Fitur export PDF sedang dalam pengembangan!', 'info');
            document.getElementById('exportModal').style.display = 'none';
        }
        
        // Fungsi untuk menampilkan notifikasi
        function showNotification(message, type) {
            // Buat elemen notifikasi
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <div style="position: fixed; top: 20px; right: 20px; background-color: ${type === 'success' ? '#06d6a0' : type === 'danger' ? '#ef476f' : type === 'warning' ? '#ffd166' : '#4361ee'}; color: white; padding: 15px 20px; border-radius: 8px; box-shadow: 0 5px 15px rgba(0,0,0,0.2); z-index: 9999; display: flex; align-items: center;">
                    <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-circle' : type === 'warning' ? 'exclamation-triangle' : 'info-circle'}" style="margin-right: 10px;"></i>
                    <span>${message}</span>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            // Hapus notifikasi setelah 3 detik
            setTimeout(() => {
                notification.remove();
            }, 3000);
        }
        
        // Event Listeners
        document.addEventListener('DOMContentLoaded', function() {
            // Tampilkan halaman login pertama kali
            showLoginPage();
            
            // Login button event
            document.getElementById('loginBtn').addEventListener('click', login);
            
            // Login dengan Enter key
            document.getElementById('password').addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    login();
                }
            });
            
            // Logout button event
            document.getElementById('logoutBtn').addEventListener('click', logout);
            
            // Menu navigation events
            document.querySelectorAll('.menu-item').forEach(item => {
                item.addEventListener('click', function() {
                    const tabName = this.getAttribute('data-tab');
                    switchTab(tabName);
                });
            });
            
            // Check in form submit event
            document.getElementById('submitCheckin').addEventListener('click', addCheckinData);
            
            // Reset form event
            document.getElementById('resetForm').addEventListener('click', function() {
                resetCheckinForm();
                resetPhotoPreviews();
            });
            
            // Generate report event
            document.getElementById('generateReport').addEventListener('click', generateReport);
            
            // Print report event
            document.getElementById('printReport').addEventListener('click', function() {
                window.print();
            });
            
            // Modal close events
            document.querySelectorAll('.modal-close').forEach(closeBtn => {
                closeBtn.addEventListener('click', function() {
                    document.getElementById('itemDetailModal').style.display = 'none';
                    document.getElementById('exportModal').style.display = 'none';
                    document.getElementById('photoGalleryModal').style.display = 'none';
                });
            });
            
            // Photo modal close
            document.querySelector('.photo-modal-close').addEventListener('click', function() {
                document.getElementById('photoModal').style.display = 'none';
            });
            
            // Close modal when clicking outside
            window.addEventListener('click', function(event) {
                if (event.target.id === 'itemDetailModal') {
                    document.getElementById('itemDetailModal').style.display = 'none';
                }
                if (event.target.id === 'exportModal') {
                    document.getElementById('exportModal').style.display = 'none';
                }
                if (event.target.id === 'photoGalleryModal') {
                    document.getElementById('photoGalleryModal').style.display = 'none';
                }
                if (event.target.id === 'photoModal') {
                    document.getElementById('photoModal').style.display = 'none';
                }
            });
        });